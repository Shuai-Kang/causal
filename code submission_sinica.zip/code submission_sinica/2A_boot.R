
# R version: R 4.3.2
# Device: AMD Ryzen 9 3900XT
# Running time: 4.654685 hours

rm(list = ls())
library(MASS)
library(xlsx)
library(gbm)
library(resample)


## bootstrap statistics
boot.tsls <- function(dat){
  A1.fit <- lm(A1 ~ Z1 + Z2, data = dat)
  A2.fit <- lm(A2 ~ Z1 + Z2, data = dat)
  Y.fit <- lm(Y ~ A1 + A2 + A1.fit$residuals + A2.fit$residuals, data = dat)
  c(Y.fit$coefficients[2],Y.fit$coefficients[3])
}

boot.gb <- function(dat){
  Z.fit <- Z.pred <- list(NULL)
  Z.fit[[1]] <- gbm(Z1 ~ A1 + A2, data = dat, distribution = 'gaussian')
  Z.fit[[2]] <- gbm(Z2 ~ A1 + A2, data = dat, distribution = 'gaussian')
  Z.pred[[1]] <- predict(Z.fit[[1]], newdata = dat, n.trees = 20)
  Z.pred[[2]] <- predict(Z.fit[[2]], newdata = dat, n.trees = 20)
  Y.fit <- lm(Y ~ A1 + A2 + Z.pred[[1]] + Z.pred[[2]], data = dat)
  c(Y.fit$coefficients[2],Y.fit$coefficients[3])
}


startTime <- Sys.time()

seedi <- 3
meths <- c('gb','tsls')
dat1 <- dat2 <- para <- case <- list(NULL)
ns <- c(100,300,500)
nsim <- 300
boot.R <- 200
alpha <- c(1,1)  # A -> Y, true treatment effect
betas <- matrix(c(0, 0, 1, 0, 1, 1), nrow = 2, ncol = 3)  # Z -> Y, exclusion restriction
gammas <- matrix(c(1, 1, 0.01, 1, 0.01, 0.01, 0, 0), nrow = 2, ncol = 4)  # Z -> A, relevance
## nrow = dim(A), ncol = # of scenarios
sigs <- list(matrix(c(1,0,0,0,1,0,0,0,1), nrow = 3, ncol = 3),
             matrix(c(1,0.5,0.5,0.5,1,0,0.5,0,1), nrow = 3, ncol = 3))
# sigs[[1]]: Z is independent of U
# sigs[[2]]: Z is dependent of U


# produce a list of parameters for all cases
case[[1]] <- list(gamma=c(1,1),beta=c(0,0),sig=sigs[[1]])
case[[2]] <- list(gamma=c(0.01,1),beta=c(0,0),sig=sigs[[1]])
case[[3]] <- list(gamma=c(0.01,0.01),beta=c(0,0),sig=sigs[[1]])
case[[4]] <- list(gamma=c(1,1),beta=c(1,0),sig=sigs[[1]])
case[[5]] <- list(gamma=c(1,1),beta=c(1,1),sig=sigs[[1]])
case[[6]] <- list(gamma=c(0.01,1),beta=c(1,1),sig=sigs[[1]])
case[[7]] <- list(gamma=c(0.01,0.01),beta=c(1,1),sig=sigs[[1]])
case[[8]] <- list(gamma=c(0,0),beta=c(0,0),sig=sigs[[2]])
case[[9]] <- list(gamma=c(0,0),beta=c(1,1),sig=sigs[[2]])


Q <- 0
for (j in 1:length(case)) {
  for (n in ns) {
    Q <- Q+1
    para[[Q]] <- append(case[[j]],list(n=n),after=0)
  }
}


# produce results for each set of parameters
for (q in c(1:Q)) {
  
  n <- para[[q]]$n
  gamma <- para[[q]]$gamma
  beta <- para[[q]]$beta
  sig <- para[[q]]$sig

  res.parallel <- list(matrix(nrow=nsim, ncol=3*length(meths)),
                       matrix(nrow=nsim, ncol=3*length(meths)))
  for (i in 1:nsim) {
    set.seed(i)
    mc.bias <- mc.sd <- mc.cov95 <- matrix(nrow = 2, ncol = length(meths))

    UZ <- mvrnorm(n, mu = c(0,0,0), Sigma = sig)
    U <- UZ[,1]
    Z1 <- UZ[,2]
    Z2 <- UZ[,3]
    e_A1 <- rexp(n, rate = 0.1)
    e_A2 <- rexp(n, rate = 0.1)
    e_Y <- rnorm(n)
    A1 <- gamma[1] * Z1 + 0.5 * U + e_A1
    A2 <- gamma[2] * Z2 + 0.5 * U + A1 + e_A2
    Y <- alpha[1] * A1 + alpha[2] * A2 + beta[1] * Z1 + beta[2] * Z2 + 0.5 * U + e_Y
    dat0 <- data.frame(A1=A1, A2=A2, Z1=Z1, Z2=Z2, Y=Y)
    
    # gradient boosting
    alphahat.gb <- boot.gb(dat = dat0)
    mc.bias[1,] <- alphahat.gb - alpha
    res.gb <- bootstrap(data=dat0, statistic=boot.gb, R=boot.R, seed=i+seedi)[['replicates']]
    mc.sd[1,] <- c(sd(res.gb[,1]),sd(res.gb[,2]))
    mc.cov95[1,1] <- (alpha[1] >= 2*alphahat.gb[1] - quantile(res.gb[,1], probs = .975) & 
                        alpha[1] <= 2*alphahat.gb[1] - quantile(res.gb[,1], probs = .025))
    mc.cov95[1,2] <- (alpha[2] >= 2*alphahat.gb[2] - quantile(res.gb[,2], probs = .975) & 
                        alpha[2] <= 2*alphahat.gb[2] - quantile(res.gb[,2], probs = .025))
    
    # benchmark: tsls
    alphahat.tsls <- boot.tsls(dat = dat0)
    mc.bias[2,] <- alphahat.tsls - alpha
    res.tsls <- bootstrap(data=dat0, statistic=boot.tsls, R=boot.R, seed=i+seedi)[['replicates']]
    mc.sd[2,] <- c(sd(res.tsls[,1]),sd(res.tsls[,2]))
    mc.cov95[2,1] <- (alpha[1] >= 2*alphahat.tsls[1] - quantile(res.tsls[,1], probs = .975) & 
                        alpha[1] <= 2*alphahat.tsls[1] - quantile(res.tsls[,1], probs = .025))
    mc.cov95[2,2] <- (alpha[2] >= 2*alphahat.tsls[2] - quantile(res.tsls[,2], probs = .975) & 
                        alpha[2] <= 2*alphahat.tsls[2] - quantile(res.tsls[,2], probs = .025))
    
    res.parallel[[1]][i,] <- matrix(cbind(mc.bias[,1],mc.sd[,1],mc.cov95[,1]),nrow=1)
    res.parallel[[2]][i,] <- matrix(cbind(mc.bias[,2],mc.sd[,2],mc.cov95[,2]),nrow=1)
  }
  
  bias.1 <- colMeans(res.parallel[[1]][,1:2]); bias.1 <- setNames(bias.1, meths)
  sd.1 <- colMeans(res.parallel[[1]][,3:4]); sd.1 <- setNames(sd.1, meths)
  cov95.1 <- colMeans(res.parallel[[1]][,5:6]); cov95.1 <- setNames(cov95.1, meths)
  dat1[[q]] <- list(para=para[[q]], bias=bias.1, sd=sd.1, cov95=cov95.1)
  
  bias.2 <- colMeans(res.parallel[[2]][,1:2]); bias.2 <- setNames(bias.2, meths)
  sd.2 <- colMeans(res.parallel[[2]][,3:4]); sd.2 <- setNames(sd.2, meths)
  cov95.2 <- colMeans(res.parallel[[2]][,5:6]); cov95.2 <- setNames(cov95.2, meths)
  dat2[[q]] <- list(para=para[[q]], bias=bias.2, sd=sd.2, cov95=cov95.2)
}

res0.1 <- matrix(unlist(dat1), ncol = 20, byrow = TRUE)
colnames(res0.1) <- names(unlist(dat1))[1:20]
ZU_dpt.1 <- (res0.1[,'para.sig2'] != 0)
res1 <- cbind(res0.1[,1:5],ZU_dpt.1,res0.1[,15:20])  # comparison results for alpha1
res0.2 <- matrix(unlist(dat2), ncol = 20, byrow = TRUE)
colnames(res0.2) <- names(unlist(dat2))[1:20]
ZU_dpt.2 <- (res0.2[,'para.sig2'] != 0)
res2 <- cbind(res0.2[,1:5],ZU_dpt.2,res0.2[,15:20])  # comparison results for alpha2


endTime <- Sys.time()
print(endTime - startTime)


# R version: R 4.3.2
# Device: AMD Ryzen 9 3900XT
# Running time: 1.650733 hours

rm(list = ls())
library(MASS)
library(randomForest)
library(Sieve)
library(AER)
library(xlsx)
library(gbm)
library(Rfast)
library(resample)


set.seed(2022)
startTime <- Sys.time()

meths <- c('sievepoly', 'sieve', 'gb', 'rf', 'tsls')
Z.fit <- Z.pred <- Y.fit <- list(NULL)
ns <- c(100, 300, 500)
nsim <- 300
alpha <- 1  # true treatment effect, A -> Y
betas <- c(0, 1)  # Z -> Y, from valid IV (beta=0) to invalid IV (beta \neq 0)
gammas <- c(0.01, 1)  # Z -> A, from weak to strong relevance

for (n in ns) {
  U <- rnorm(n)
  Z <- rnorm(n)
  for (beta in betas) {
    mc.Z <- matrix(nrow = length(meths), ncol = length(gammas))
    mc.bias <- mc.sd <- mc.cov95 <- matrix(nrow = length(meths), ncol = length(gammas))
    for (j in c(1:length(gammas))) {
      count <- numeric(length(meths))
      alphahat <- alphahat.sd <- matrix(nrow = length(meths), ncol = nsim)
      Zhat <- matrix(nrow = length(meths), ncol = nsim)
      
      sim_data <- matrix(nrow = n, ncol = 3*nsim)
      for (i in 1:nsim) {
        e_A <- rexp(n, rate = 0.1)
        e_Y <- rnorm(n)  # e_Y is not necessarily Gaussian!!
        A <- gammas[j] * Z + 0.5 * U + e_A
        Y <- alpha * A + beta * Z + 0.5 * U + e_Y
        
        sim_data[,3*i-2] <- Z
        sim_data[,3*i-1] <- A
        sim_data[,3*i] <- Y
        
        dat0 <- data.frame(A=A, Z=Z, U=U, Y=Y)
        # outcome Y must be in the last column, otherwise an error would occur in sieve estimation

        ### benchmark: tsls
        Y.fit[[5]] <- ivreg(Y ~ A | Z, data = dat0)
        alphahat[5, i] <- Y.fit[[5]]$coefficients[2]
        alphahat.sd[5, i] <- summary(Y.fit[[5]])$coefficients[2, 2]
        count[5] <- count[5] + (alpha >= confint(Y.fit[[5]])[2,1] && alpha <= confint(Y.fit[[5]])[2,2])

        ### proposed method
        # sieve estimation via polynomial basis function
        Z.fit[[1]] <- lm(Z ~ poly(A, 5, raw = TRUE), data = dat0)
        Z.pred[[1]] <- predict(Z.fit[[1]], newdata = dat0)
        Y.fit[[1]] <- lm(Y ~ A + Z.pred[[1]], data = dat0)
        alphahat[1, i] <- Y.fit[[1]]$coefficients[2]
        alphahat.sd[1, i] <- summary(Y.fit[[1]])$coefficients[2, 2]
        count[1] <- count[1] + (alpha >= confint(Y.fit[[1]])[2,1] && alpha <= confint(Y.fit[[1]])[2,2])
        Zhat[1, i] <- mean(Z.pred[[1]])

        # sieve estimation
        Z.model <- sieve_preprocess(X = dat0[, 'A'], basisN = 5, interaction_order = 1)
        Z.fit[[2]] <- sieve_solver(model = Z.model, Y = dat0[, 'Z'])
        Z.pred0 <- sieve_predict(model = Z.fit[[2]],
                                 testX = dat0[, 'A'],
                                 testY = dat0[, 'Z'])
        lambda.ind <- min(60, which.min(Z.pred0$MSE))
        # plot(Z.pred0$MSE)  # determine a proper lambda (similar as stopping criteria)
        Z.pred[[2]] <- Z.pred0$predictY[, lambda.ind]
        Y.fit[[2]] <- lm(Y ~ A + Z.pred[[2]], data = dat0)
        alphahat[2, i] <- Y.fit[[2]]$coefficients[2]
        alphahat.sd[2, i] <- summary(Y.fit[[2]])$coefficients[2, 2]
        count[2] <- count[2] + (alpha >= confint(Y.fit[[2]])[2,1] && alpha <= confint(Y.fit[[2]])[2,2])
        Zhat[2, i] <- mean(Z.pred[[2]])

        # gradient boosting
        Z.fit[[3]] <- gbm(Z ~ A, data = dat0, distribution = 'gaussian')
        Z.pred[[3]] <- predict(Z.fit[[3]], newdata = dat0, n.trees = 50)
        Y.fit[[3]] <- lm(Y ~ A + Z.pred[[3]], data = dat0)
        alphahat[3, i] <- Y.fit[[3]]$coefficients[2]
        alphahat.sd[3, i] <- summary(Y.fit[[3]])$coefficients[2, 2]
        count[3] <- count[3] + (alpha >= confint(Y.fit[[3]])[2,1] && alpha <= confint(Y.fit[[3]])[2,2])
        Zhat[3, i] <- mean(Z.pred[[3]])

        # random forest
        Z.fit[[4]] <- randomForest(Z ~ A, data = dat0, ntree = 100)
        Z.pred[[4]] <- predict(Z.fit[[4]], newdata = dat0)
        Y.fit[[4]] <- lm(Y ~ A + Z.pred[[4]], data = dat0)
        alphahat[4, i] <- Y.fit[[4]]$coefficients[2]
        alphahat.sd[4, i] <- summary(Y.fit[[4]])$coefficients[2, 2]
        count[4] <- count[4] + (alpha >= confint(Y.fit[[4]])[2,1] && alpha <= confint(Y.fit[[4]])[2,2])
        Zhat[4, i] <- mean(Z.pred[[4]])
      }
      
      save(sim_data, file=paste0("n",n,"gamma",gammas[j],"beta",beta,"ZU_dptFALSE",".rdata"))

      mc.bias[, j] <- rowMeans(alphahat) - alpha
      mc.sd[, j] <- rowMeans(alphahat.sd)
      mc.cov95[, j] <- count / nsim
      mc.Z[, j] <- rowMeans(Zhat)
    }
    
    rownames(mc.bias) <- c('bias.sievepoly', 'bias.sieve', 'bias.gb', 'bias,rf', 'bias.tsls')
    rownames(mc.sd) <- c('sd.sievepoly', 'sd.sieve', 'sd.gb', 'sd.rf', 'sd.tsls')
    rownames(mc.cov95) <- c('cov.sievepoly', 'cov.sieve', 'cov.gb', 'cov.rf', 'cov.tsls')
    colnames(mc.bias) <- colnames(mc.sd) <- colnames(mc.cov95) <- as.character(gammas)

    filename_biasgb <- paste0("biasgb_n",n,"beta",beta,"ZU_dptFALSE",".rdata")
    save(mc.bias, file=filename_biasgb)
  }
}




Z.fit <- Z.pred <- Y.fit <- rep(list(NULL),length(meths))
ns <- c(100, 300, 500)
nsim <- 300
alpha <- 1  # true treatment effect, A -> Y
betas <- c(0, 1)  # Z -> Y, from valid IV (beta=0) to invalid IV (beta \neq 0)
gammas <- c(0, 1)  # Z -> A, from weak to strong relevance
xis <- c(0.5)  # covariance between U and Z

for (gamma in gammas) {
  
  for (xi in xis) {
    
    for (n in ns) {
      UZ <- rmvnorm(n, mu = c(0,0), sigma = matrix(c(1,xi,xi,1), nrow = 2, ncol = 2), 
                    seed = 2022)
      U <- UZ[,1]
      Z <- UZ[,2]
      for (beta in betas) {
        mc.bias <- mc.sd <- mc.cov95 <- matrix(nrow = length(meths), ncol = 1)
        count <- numeric(length(meths))
        alphahat <- alphahat.sd <- matrix(nrow = length(meths), ncol = nsim)
        
        sim_data <- matrix(nrow = n, ncol = 3*nsim)
        for (i in 1:nsim) {
          # e_A <- runif(n, min = -0.5, max = 0.5)  # epsilon_A is non-Gaussian
          e_A <- rexp(n, rate = 0.1)
          e_Y <- rnorm(n)  # e_Y is Gaussian since Y is Gaussian
          
          A <- gamma * Z + 0.5 * U + e_A
          Y <- alpha * A + beta * Z + 0.5 * U + e_Y
          
          sim_data[,3*i-2] <- Z
          sim_data[,3*i-1] <- A
          sim_data[,3*i] <- Y
          
          dat0 <- data.frame(A=A, Z=Z, U=U, Y=Y)  
          # outcome Y must be in the last column, otherwise an error would occur in sieve estimation
          
          ### benchmark: tsls
          Y.fit[[5]] <- ivreg(Y ~ A | Z, data = dat0)
          alphahat[5, i] <- Y.fit[[5]]$coefficients[2]
          alphahat.sd[5, i] <- summary(Y.fit[[5]])$coefficients[2, 2]
          count[5] <- count[5] + (alpha >= confint(Y.fit[[5]])[2,1] && alpha <= confint(Y.fit[[5]])[2,2])
          
          ### proposed method
          # sieve estimation via polynomial basis function
          Z.fit[[1]] <- lm(Z ~ poly(A, 5, raw = TRUE), data = dat0)
          Z.pred[[1]] <- predict(Z.fit[[1]], newdata = dat0)
          Y.fit[[1]] <- lm(Y ~ A + Z.pred[[1]], data = dat0)
          alphahat[1, i] <- Y.fit[[1]]$coefficients[2]
          alphahat.sd[1, i] <- summary(Y.fit[[1]])$coefficients[2, 2]
          count[1] <- count[1] + (alpha >= confint(Y.fit[[1]])[2,1] && alpha <= confint(Y.fit[[1]])[2,2])
          
          
          # sieve estimation
          Z.model <- sieve_preprocess(X = dat0[, 'A'], basisN = 5, interaction_order = 1)
          Z.fit[[2]] <- sieve_solver(model = Z.model, Y = dat0[, 'Z'])
          Z.pred0 <- sieve_predict(model = Z.fit[[2]],
                                   testX = dat0[, 'A'],
                                   testY = dat0[, 'Z'])
          lambda.ind <- min(60, which.min(Z.pred0$MSE))
          # plot(Z.pred0$MSE)  # determine a proper lambda (similar as stopping criteria)
          Z.pred[[2]] <- Z.pred0$predictY[, lambda.ind]
          Y.fit[[2]] <- lm(Y ~ A + Z.pred[[2]], data = dat0)
          alphahat[2, i] <- Y.fit[[2]]$coefficients[2]
          alphahat.sd[2, i] <- summary(Y.fit[[2]])$coefficients[2, 2]
          count[2] <- count[2] + (alpha >= confint(Y.fit[[2]])[2,1] && alpha <= confint(Y.fit[[2]])[2,2])
          
          # gradient boosting
          Z.fit[[3]] <- gbm(Z ~ A, data = dat0, distribution = 'gaussian')
          Z.pred[[3]] <- predict(Z.fit[[3]], newdata = dat0, n.trees = 50)
          Y.fit[[3]] <- lm(Y ~ A + Z.pred[[3]], data = dat0)
          alphahat[3, i] <- Y.fit[[3]]$coefficients[2]
          alphahat.sd[3, i] <- summary(Y.fit[[3]])$coefficients[2, 2]
          count[3] <- count[3] + (alpha >= confint(Y.fit[[3]])[2,1] && alpha <= confint(Y.fit[[3]])[2,2])
          
          # random forest
          Z.fit[[4]] <- randomForest(Z ~ A, data = dat0, ntree = 100)
          Z.pred[[4]] <- predict(Z.fit[[4]], newdata = dat0)
          Y.fit[[4]] <- lm(Y ~ A + Z.pred[[4]], data = dat0)
          alphahat[4, i] <- Y.fit[[4]]$coefficients[2]
          alphahat.sd[4, i] <- summary(Y.fit[[4]])$coefficients[2, 2]
          count[4] <- count[4] + (alpha >= confint(Y.fit[[4]])[2,1] && alpha <= confint(Y.fit[[4]])[2,2])
          
        }
        save(sim_data, file=paste0("n",n,"gamma",gamma,"beta",beta,"ZU_dptTRUE",".rdata"))

        mc.bias[, 1] <- rowMeans(alphahat) - alpha
        mc.sd[, 1] <- rowMeans(alphahat.sd)
        mc.cov95[, 1] <- count / nsim
        
        filename_biasgb <- paste0("biasgb_n",n,"gamma",gamma,"beta",beta,"ZU_dptTRUE",".rdata")
        save(mc.bias, file=filename_biasgb)
      }
    }
  }
}




## bootstrap statistics
boot.tsls <- function(data){
  dat <- data
  A.fit <- lm(A ~ Z, data = dat)
  Y.fit <- lm(Y ~ A + A.fit$residuals, data = dat)
  Y.fit$coefficients[2]
}

boot.gb <- function(data){
  dat <- data
  Z.fit <- gbm(Z ~ A, data = dat, distribution = 'gaussian')
  Z.pred <- predict(Z.fit, newdata = dat, n.trees = 50)
  Y.fit <- lm(Y ~ A + Z.pred, data = dat)
  Y.fit$coefficients[2]
}


meths <- c('gb','tsls')
dat <- para <- case <- list(NULL)
ns <- c(100,300,500)
nsim <- 300
boot.R <- 200
alpha <- 1  # A -> Y, true treatment effect
betas <- c(0,1)  # Z -> Y
gammas <- c(1,0.01)  # Z -> A
sigs <- list(matrix(c(1,0,0,1), nrow = 2, ncol = 2), 
             matrix(c(1,0.5,0.5,1), nrow = 2, ncol = 2))
# sigs[[1]]: Z is independent on U; sigs[[2]]: Z is dependent of U

# produce a list of parameters for all cases
case[[1]] <- list(gamma=1,beta=0,sig=sigs[[1]])
case[[2]] <- list(gamma=0.01,beta=0,sig=sigs[[1]])
case[[3]] <- list(gamma=1,beta=1,sig=sigs[[1]])
case[[4]] <- list(gamma=1,beta=0,sig=sigs[[2]])
case[[5]] <- list(gamma=1,beta=1,sig=sigs[[2]])
case[[6]] <- list(gamma=0,beta=0,sig=sigs[[2]])
case[[7]] <- list(gamma=0,beta=1,sig=sigs[[2]])

Q <- 0
for (j in 1:length(case)) {
  for (n in ns) {
    Q <- Q+1
    para[[Q]] <- append(case[[j]],list(n=n),after=0)
  }
}


seedi <- 24
# produce results for each set of parameters
for (q in c(1:Q)) {
  
  n <- para[[q]]$n
  gamma <- para[[q]]$gamma
  beta <- para[[q]]$beta
  sig <- para[[q]]$sig
  
  filename <- paste0("n",n,"gamma",gamma,"beta",beta,"ZU_dpt",(sig[1,2]!=0),".rdata")
  sim_data <- local(get(load(filename)))
  
  res.parallel <- matrix(nrow = nsim, ncol = 3*length(meths))
  for (i in 1:nsim) {
    
    mc.bias <- mc.sd <- mc.cov95 <- rep(NA, length(meths))
    
    dat0 <- data.frame(Z=sim_data[,3*i-2],A=sim_data[,3*i-1],Y=sim_data[,3*i])
    
    # gradient boosting
    if((sig[1,2]!=0)){
      filename_biasgb <- paste0("biasgb_n",n,"gamma",gamma,"beta",beta,"ZU_dptTRUE",".rdata")
      biasgb <- local(get(load(filename_biasgb)))
      mc.bias <- biasgb[3,1]
    } else {
      filename_biasgb <- paste0("biasgb_n",n,"beta",beta,"ZU_dptFALSE",".rdata")
      biasgb <- local(get(load(filename_biasgb)))
      mc.bias <- biasgb['bias.gb',as.character(gamma)]
    }
    alphahat.gb <- mc.bias[1] + alpha
    res.gb <- bootstrap(data=dat0, statistic=boot.gb, R=boot.R, seed=i+seedi)[['replicates']]
    mc.sd[1] <- sd(res.gb)
    mc.cov95[1] <- (alpha >= 2*alphahat.gb - quantile(res.gb, probs = .975) & 
                      alpha <= 2*alphahat.gb - quantile(res.gb, probs = .025))
    
    # benchmark: tsls
    alphahat.tsls <- boot.tsls(data = dat0)
    mc.bias[2] <- alphahat.tsls - alpha
    res.tsls <- bootstrap(data=dat0, statistic=boot.tsls, R=boot.R, seed=i+seedi)[['replicates']]
    mc.sd[2] <- sd(res.tsls)
    mc.cov95[2] <- (alpha >= 2*alphahat.tsls - quantile(res.tsls, probs = .975) & 
                      alpha <= 2*alphahat.tsls - quantile(res.tsls, probs = .025))
    
    res.parallel[i,] <- matrix(cbind(mc.bias,mc.sd,mc.cov95),nrow=1)
  }
  
  bias <- colMeans(res.parallel[,1:2]); bias <- setNames(bias, meths)
  sd <- colMeans(res.parallel[,3:4]); sd <- setNames(sd, meths)
  cov95 <- colMeans(res.parallel[,5:6]); cov95 <- setNames(cov95, meths)
  dat[[q]] <- list(para=para[[q]], bias=bias, sd=sd, cov95=cov95)
}

res0 <- matrix(unlist(dat), ncol = 13, byrow = TRUE)
colnames(res0) <- names(unlist(dat))[1:13]
ZU_dpt <- (res0[,'para.sig2'] != 0)
res <- cbind(res0[,1:3],ZU_dpt,res0[,8:13])  # comparison results for alpha


endTime <- Sys.time()
print(endTime - startTime)


# R version: R 4.2.2
# Device: AMD Ryzen 9 3900XT
# Running time: 3.544571 mins

rm(list = ls())
library(MASS)
library(xlsx)
library(AER)
library(gbm)
library(ggplot2)

set.seed(2022)

startTime <- Sys.time()

meths <- c('gb', 'tsls')
ind4meths <- data.frame(gb = 1, tsls = 2)
Z.fit <- Z.pred <- Y.fit <- dat <- list(NULL)
ns <- 300
nsim <- 300
alpha <- 1  # A -> Y, true treatment effect
betas <- 1  # Z -> Y
gamma <- 1  # Z -> A
nu <- seq(5, 30, 0.5)  # degrees of freedom for t-distribution
sigs <- list(matrix(c(1,0.5,0.5,1), nrow = 2, ncol = 2), matrix(c(1,0,0,1), nrow = 2, ncol = 2))
# sigs[[1]]: Z is dependent on U; sigs[[2]]: Z is independent of U

for (p in 1:length(sigs)) {

  for (n in ns) {
  
    sig <- sigs[[p]]
    UZ <- mvrnorm(n, mu = c(0,0), Sigma = sig)
    U <- UZ[,1]
    Z <- UZ[,2]
    
    for (beta in betas) {
      
      mc.Z <- matrix(nrow = length(meths), ncol = length(nu))
      mc.bias <- mc.sd <- mc.cov95 <- matrix(nrow = length(meths), ncol = length(nu))
        
        for (j in 1:length(nu)) {
          
          count <- numeric(length(meths))
          alphahat <- alphahat.sd <- matrix(nrow = length(meths), ncol = nsim)
    
          for (i in 1:nsim) {
            
            e_A <- rexp(n, 0.1)
            e_Y <- rnorm(n)
            
            W <- rt(n, df = nu[j])
            A <- gamma * Z + 0.5 * U + W +  e_A
            Y <- alpha * A + beta * Z + 0.5 * U + W + e_Y
            
            dat0 <- data.frame(A=A, Z=Z, U=U, Y=Y)  
    
            ### benchmark: tsls
            Y.fit[[ind4meths[['tsls']]]] <- ivreg(Y ~ A | Z, data = dat0)
            alphahat[ind4meths[['tsls']], i] <- Y.fit[[ind4meths[['tsls']]]]$coefficients[2]
            alphahat.sd[ind4meths[['tsls']], i] <- summary(Y.fit[[ind4meths[['tsls']]]])$coefficients[2, 2]
            count[ind4meths[['tsls']]] <- count[ind4meths[['tsls']]] + 
              (alpha[1] >= confint(Y.fit[[ind4meths[['tsls']]]])[2,1] 
               && alpha[1] <= confint(Y.fit[[ind4meths[['tsls']]]])[2,2])
    
            # gradient boosting
            Z.fit[[ind4meths[['gb']]]] <- gbm(Z ~ A, data = dat0, distribution = 'gaussian')
            Z.pred[[ind4meths[['gb']]]] <- predict(Z.fit[[ind4meths[['gb']]]], newdata = dat0, n.trees = 50)
            Y.fit[[ind4meths[['gb']]]] <- lm(Y ~ A + Z.pred[[ind4meths[['gb']]]], data = dat0)
            alphahat[ind4meths[['gb']], i] <- Y.fit[[ind4meths[['gb']]]]$coefficients[2]
            alphahat.sd[ind4meths[['gb']], i] <- summary(Y.fit[[ind4meths[['gb']]]])$coefficients[2, 2]
            count[ind4meths[['gb']]] <- count[ind4meths[['gb']]] + 
              (alpha[1] >= confint(Y.fit[[ind4meths[['gb']]]])[2,1] 
               && alpha[1] <= confint(Y.fit[[ind4meths[['gb']]]])[2,2])
  
          }
        
          mc.bias[, j] <- rowMeans(alphahat) - alpha
          mc.sd[, j] <- rowMeans(alphahat.sd)
          mc.cov95[, j] <- count / nsim
    
        }
        
        bias.name <- sd.name <- cov.name <- NULL
        for (k in 1:length(meths)) {
          bias.name <- cbind(bias.name, paste0("bias.", meths[k]))
          sd.name <- cbind(sd.name, paste0("sd.", meths[k]))
          cov.name <- cbind(cov.name, paste0("cov.", meths[k]))
        }
        rownames(mc.bias) <- bias.name
        rownames(mc.sd) <- sd.name
        rownames(mc.cov95) <- cov.name
  
        dat[[p]] <- data.frame(t(rbind(nu, abs(mc.bias))))
        print(ggplot() + geom_line(data=dat[[p]], aes(x = nu, y = bias.gb), linewidth = 0.5) + 
                theme_bw() + 
                labs(y = "Absolute bias", x = 'Degrees of freedom') + 
                scale_x_continuous(n.breaks = 8) + 
                coord_cartesian(ylim = c(0, 0.005)))
      
    }
    
  }

}
endTime <- Sys.time()

print(endTime - startTime)


# R version: R 4.2.2
# Device: AMD Ryzen 9 3900XT
# Running time: 2.385608 mins

rm(list = ls())
library(ivtools)
library(randomForest)
library(AER)
library(MASS)
library(Sieve)
library(xlsx)
library(dplyr)
library(gbm)
library(ggplot2)
library(readxl)
library(nortest)
library(neuralnet)
library(RSNNS)

setwd("...")
set.seed(2022)

startTime <- Sys.time()

for (targetZ in c("annwat")) {
  
  for (trunc.prob in c(0)) {
    
    targetZlog <- paste0(targetZ, ".log")
    datafile <- c("WBdata.xlsx")
    worldbank <- read_xlsx(datafile, sheet = "Data")
    data <- data.frame(worldbank[, 5:ncol(worldbank)])
    colnames(data) <- c("income.pc", "exp", "imp",
                        "agri.irrigl.pct", "agril.pct", "agril",
                        "arbl.pct", "arbl", "arbl.pp",
                        "land", "fore.pct",
                        "annwat.agri", "annwat.dome", "annwat.tot", "annwat.indu", "annwat",
                        "pop", "labor")
    data <- data %>% mutate_if(is.character, as.numeric)
    data['trade'] <- data$exp + data$imp
    
    select <- c("income.pc", "trade", targetZ)
    dat1 <- data[, select]
    dat1 <- data[rowSums(is.na(dat1)) == 0,]  # remove NAs in selected data
    dat1 <- dat1[dat1[,1] > 0 & dat1[,3] > 0,]  # prepare for taking log value
    dat1["income.pc.log"] <- log(dat1[,"income.pc"])
    dat1[targetZlog] <- log(dat1[,targetZ])
    select <- c("income.pc.log", "trade", targetZlog)  # select logged variables
    dat2 <- data.frame(scale(dat1[, select]))
    
    meths <- c('2SLS', 'Sieve', 'RF', 'GB', 'MLP')
    nsim <- 300
    
    alphahat.tsls <- NULL; alphahat.sieve <- NULL; alphahat.rf <- NULL
    alphahat.nn <- NULL; alphahat.gb <- NULL; alphahat.sievepoly <- NULL
    alphahat.mlp <- NULL
    sd.tsls <- NULL; sd.sieve <- NULL; sd.rf <- NULL
    sd.nn <- NULL; sd.gb <- NULL; sd.sievepoly <- NULL
    sd.mlp <- NULL
    
    colnames(dat2) <- c("Y", "A", "Z")
    
    # remove outliers if needed
    quant <- quantile(dat2$Z, probs = c(trunc.prob, 1 - trunc.prob))
    dat2 <- dat2[dat2$Z <= quant[2] & dat2$Z >= quant[1], ]
    ad.test(dat2$Z)  # perform AD test
    nsamp <- nrow(dat2)
    
    for (i in 1:nsim) {
      ind <- sample(1:nsamp, nsamp, replace = TRUE)
      dat0 <- dat2[ind, ]
      
      # benchmark: tsls
      ivreg.fit <- ivreg(Y ~ A | Z, data = dat0)
      alphahat.tsls[i] <- ivreg.fit$coefficients[2]
      sd.tsls[i] <- summary(ivreg.fit)$coefficients[2,2]
      
      # sieve estimation
      model.sieve <- sieve_preprocess(X = dat0[, c(2)], basisN = 20)
      fit0.sieve <- sieve_solver(model = model.sieve, Y = dat0[, 3])
      pred0.sieve <- sieve_predict(model = fit0.sieve,
                                   testX = dat0[, c(2)],
                                   testY = dat0[, 3])
      lambda.ind <- min(60, which.min(pred0.sieve$MSE))  # avoid overfitting
      pred.sieve <- pred0.sieve$predictY[, lambda.ind]
      fit.sieve <- lm(Y ~ A + pred.sieve, data = dat0)
      alphahat.sieve[i] <- fit.sieve$coefficients[2]
      sd.sieve[i] <- summary(fit.sieve)$coefficients[2,2]
      
      # random forest
      fit0.rf <- randomForest(Z ~ A, data = dat0)
      pred.rf <- predict(fit0.rf, data = dat0)
      fit.rf <- lm(Y ~ A + pred.rf, data = dat0)
      alphahat.rf[i] <- fit.rf$coefficients[2]
      sd.rf[i] <- summary(fit.rf)$coefficients[2,2]
      
      # gradient boosting
      fit0.gb <- gbm(Z ~ A, data = dat0, distribution = 'gaussian')
      pred.gb <- predict(fit0.gb, newdata = dat0, n.trees = 20)
      fit.gb <- lm(Y ~ A + pred.gb, data = dat0)
      alphahat.gb[i] <- fit.gb$coefficients[2]
      sd.gb[i] <- summary(fit.gb)$coefficients[2,2]
      
      # MLP
      pred.mlp <- NULL
      fit0.mlp <- mlp(x = dat0$A, y = dat0$Z)
      for (j in 1:length(dat0$A)) {
        pred.mlp[j] <- predict(fit0.mlp, newdata = dat0[j, "A"])
      }
      fit.mlp <- lm(Y ~ A + pred.mlp, data = dat0)
      alphahat.mlp[i] <- fit.mlp$coefficients[2]
      sd.mlp[i] <- summary(fit.mlp)$coefficients[2, 2] 
      
    }

    alphahats <- c(mean(alphahat.tsls), mean(alphahat.sieve), mean(alphahat.rf),
                   mean(alphahat.gb), 
                   mean(alphahat.mlp))
    alphahats.sd <- c(mean(sd.tsls), mean(sd.sieve), mean(sd.rf),
                      mean(sd.gb), 
                      mean(sd.mlp))
    ci <- data.frame(x = meths, y = alphahats,
                     up = alphahats + 1.96 * alphahats.sd,
                     low = alphahats - 1.96 * alphahats.sd)

    ci$x <- factor(ci$x, levels = c('GB', 'RF', 'Sieve', 'MLP', '2SLS'))
    # modify the order of methods along x axis
    
    print(ggplot(ci, aes(x, y)) + geom_point() +
      geom_errorbar(aes(ymin = low, ymax = up), width = 0.3) +
      theme_bw() +
      geom_hline(yintercept = 0, linetype = 'dashed') +
      labs(x = 'Methods', y = 'Estimates of causal effect') + 
      scale_y_continuous(n.breaks = 10))
    
  }
  
}

endTime <- Sys.time()

print(endTime - startTime)
